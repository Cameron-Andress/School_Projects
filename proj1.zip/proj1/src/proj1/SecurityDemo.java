package proj1;
import java.util.ArrayList;
import java.util.Scanner;

public class SecurityDemo {
    static Scanner keyboard = new Scanner(System.in);
    
    public static void main(String args[]){ 
       boolean exitProgram = false;
       
       SecuritySystem securitySystem = new SecuritySystem();
       
       while (!exitProgram) {
           
            ArrayList<String> userNames = securitySystem.getUsers();

            String[] users = new String[userNames.size()];
            int index = 0;

            for (String userName : userNames) {
                users[index] = userName;
                index++;
            }
                    
            System.out.println("Please type one of the following numbers:");
            System.out.println("0 - exit program.");
            System.out.println("1 - send a message.");
            System.out.println("2 - view inbox.");
            System.out.println("3 - view users.\n");

            //SecureMessage secureMessage = new SecureMessage("adsf", "ad", "adf", "sdfasfd");

            String choice;
            choice = keyboard.next();

            switch (choice){
                case "0":
                    System.out.println("\nThanks for using the Secure Messaging Program. Goodbye!");
                    exitProgram = true;
                    break;
                case "1":
                    System.out.println("Send a message to whom and from whom in the form:\n     To From Message : Key\n");
                    
                    for (int i=0; i < users.length; i++) {
                        System.out.println((i + 1) + " - " + users[i]);
                    }
                    
                    System.out.println("");
                    
                    int recipientNumber = keyboard.nextInt();
                    int senderNumber = keyboard.nextInt();
                    String messageAndKey = keyboard.nextLine();
                    
                    int separatorIndex = messageAndKey.indexOf(" : ");
                    
                    String message = messageAndKey.substring(1, separatorIndex);
                    String key = messageAndKey.substring(separatorIndex + 3, messageAndKey.length());
                    
                    String recipient = users[recipientNumber - 1];
                    String sender = users[senderNumber - 1];
                    
                    securitySystem.addMessage(recipient, sender, message, key);
                    System.out.println("Sent a message from " + sender + " to " + recipient + " \"" + message + "\"\n");
                    break;
                case "2":
                    System.out.println("\nView your inbox. Who are you?\n");
                    
                    for (int i=0; i < users.length; i++) {
                        System.out.println((i + 1) + " - " + users[i]);
                    }
                    
                    System.out.println("");
                    
                    recipientNumber = keyboard.nextInt();
                    recipient = users[recipientNumber - 1];
                    
                    ArrayList<SecureMessage> secureMessages = securitySystem.findMessagesForUser(recipient);
                    
                    boolean mainMenu = false;
                    
                    while(!mainMenu) {
                        System.out.println("\nHello " + recipient + ", you have " + secureMessages.size() + " messages waiting for you. Which do you want to read?\n Type 0 to go back to main menu.\n\n"
                                           + "(Type the number of the message)\n");

                        int messageNumber = 1;

                        for (SecureMessage secureMessage : secureMessages) {
                            System.out.println(messageNumber + " - From " + secureMessage.getSourceName());
                            messageNumber++;
                        }

                        System.out.println("");

                        int messageIndex = keyboard.nextInt();

                        if (messageIndex == 0) {
                            mainMenu = true;
                        }
                        else {
                            SecureMessage secureMessage = secureMessages.get(messageIndex - 1);
                            System.out.println("\nWhat is the key to read your message?\n");

                            String messageKey = keyboard.next();

                            String messageRead = secureMessage.getMessage(messageKey);

                            if (messageRead.equals("Secret key does not match stored key. Message cannot be returned without authentication.")) {
                                System.out.println("\nIncorrect key.");
                            }
                            else {
                                System.out.println("\nCorrect! Your message is:");
                                System.out.println(messageRead);
                            }
                        }
                    }
                    
                    break;
                case "3":
                    System.out.println("\nUser list:\n");
                    
                    for (int i=0; i < users.length; i++) {
                        System.out.println((i + 1) + " - " + users[i]);
                    }
                    
                    System.out.println("");
                    
                    break;
                default:
                    break;
            }// end of switch
       }
    }// end of main
       
}// end of SecurityDemo
