package proj1;
import java.util.ArrayList;
import java.util.Arrays;

public class SecuritySystem {
    
    ArrayList<SecureMessage> secureMessages = new ArrayList<>();
     
    ArrayList<String> userNames = new ArrayList<>(Arrays.asList("Max", "Ksenia", "Sally", "Ali", "Tyrone"));
 
    public ArrayList<SecureMessage> findMessagesForUser(String userName) {
        ArrayList<SecureMessage> secureMessagesForUser = new ArrayList<>();
        
        for (SecureMessage secureMessage : secureMessages) {
            if (secureMessage.getDestName().equals(userName)) {
                secureMessagesForUser.add(secureMessage);
            }
        }
        
        return secureMessagesForUser;
    }
    
    
    public ArrayList<String> getUsers() {
        return userNames;
    }
    
    public void addMessage(String recipient, String sender, String message, String key) {
        SecureMessage secureMessage = new SecureMessage(message, sender, key, recipient);
        secureMessages.add(secureMessage);
    }
}// end SecuritySystem
