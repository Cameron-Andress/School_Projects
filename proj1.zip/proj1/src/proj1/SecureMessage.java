package proj1;

public class SecureMessage {
    //variables for this class
    // Can not be changed
private String message;
private String sourceName;
private String key;
private String destName;

public SecureMessage(String message, String sourceName, String key, String destName) {
    this.message = message;
    this.sourceName = sourceName;
    this.key = key;
    this.destName = destName;
}

public String getMessage(String key){
    if (this.key != null && this.key.equals(key)) {
        return message;
    }
    else {
        return "Secret key does not match stored key. Message cannot be returned without authentication.";
    }
}// end of getMessage

public String getSourceName(){
    return sourceName;
}// end of getSourceName

public String getDestName(){
    return destName; 
}// end of getDestName



}// end of SecureMessage
