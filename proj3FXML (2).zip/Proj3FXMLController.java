package proj3FX;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class Proj3FXMLController implements Initializable {
    @FXML
    ListView<String> lvMovies;
    
    ObservableList<String> list = FXCollections.observableArrayList();
    
    @FXML
    private TextField myTextField;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       lvMovies.setItems(list);    
    }   //end initialize 

    @FXML
    private void addButton(ActionEvent event) {
        boolean selected1 = true;
        boolean notSelected1 = true;
        if(selected1 == true){
           list.add(myTextField.getText());
        }//end if
        if(notSelected1 != true){
            Alert alert = new Alert(AlertType.WARNING);
            alert.setHeaderText("Please type soemthing in the textfield.");
            alert.setTitle("Alert!");
            alert.setContentText("Alert!");
            alert.showAndWait(); 
        }//end if
    }//end addButton

    @FXML
    public void removeButton(ActionEvent event) {
        boolean selected = true;
        boolean notSelected = false;
        if(selected == true){
           int selectedItem = lvMovies.getSelectionModel().getSelectedIndex();
           list.remove(selectedItem);
        }// end if
        if(notSelected != false){
            Alert alert = new Alert(AlertType.WARNING);
            alert.setHeaderText("Please select something to remove.");
            alert.setTitle("Alert!");
            alert.setContentText("Alert!");
            alert.showAndWait();
        } // end if
    }//end removeButton
    
    @FXML
    public void saveButton(ActionEvent event) throws FileNotFoundException {
        try (PrintWriter pw = new PrintWriter(new File("movies.txt"))) {
            pw.println(list);
            pw.close();
            
        }// end try
        catch(IOException e){
            Alert alert = new Alert(AlertType.WARNING);
            alert.setHeaderText("An error has occured.");
            alert.setTitle("Alert!");
            alert.setContentText("Alert!");
            alert.showAndWait();
        }//end catch
    }//end saveButton

    @FXML
    public void loadButton(ActionEvent event) throws FileNotFoundException {
        try (Scanner reader = new Scanner(new File("movies.txt"))) {
            while (reader.hasNextLine()){
                String line = reader.nextLine();
                String lineLowerCase = line.toLowerCase();
                list.add(lineLowerCase);
                
            }//end while
        }//end try
        catch(IOException e){
            Alert alert = new Alert(AlertType.WARNING);
            alert.setHeaderText("Something went wrong.");
            alert.setTitle("Alert!");
            alert.setContentText("Alert!");
            alert.showAndWait();
        }// end catch
    }// end loadButton 
}// end Proj3FMXLController